export class Student {

    id:any;
    studentname:any;
    batch:any;
    branch:any;
}
