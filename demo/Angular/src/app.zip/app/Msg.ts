export class Msg {
  Msg: string;
       }
